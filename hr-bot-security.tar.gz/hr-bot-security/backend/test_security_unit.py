"""Модульная проверка security.py на текстах реальных примеров атак."""
import sys

sys.path.insert(0, ".")

from app import security  # noqa: E402
from app.config import settings  # noqa: E402

with open("samples/resume_injection_basic.txt", encoding="utf-8") as f:
    basic = f.read()
with open("samples/resume_injection_leak.txt", encoding="utf-8") as f:
    leak = f.read()
with open("samples/resume_clean.txt", encoding="utf-8") as f:
    clean = f.read()

print("--- Уровень 1: фильтрация ввода ---")
for name, text in [("clean", clean), ("basic", basic), ("leak", leak)]:
    r0 = security.filter_user_input(text, level=0)
    r1 = security.filter_user_input(text, level=1)
    print(f"{name}: level0 events={len(r0.events)}  level1 events={len(r1.events)}")
    if r1.events:
        for e in r1.events:
            print("   ", e.kind, "-", e.detail[:90])

assert len(security.filter_user_input(clean, 1).events) == 0
assert len(security.filter_user_input(basic, 1).events) > 0
assert len(security.filter_user_input(leak, 1).events) > 0
print("OK: чистое резюме не триггерит фильтр, атакующие — триггерят.\n")

print("--- Уровень 2: изоляция недоверенных данных ---")
wrapped = security.wrap_untrusted("resume_file", basic, level=2)
assert "<untrusted_data" in wrapped and "ДАННЫЕ" in wrapped
not_wrapped = security.wrap_untrusted("resume_file", basic, level=1)
assert not_wrapped == basic
print("OK: на уровне >=2 текст оборачивается меткой untrusted_data, на уровне <2 — нет.\n")

print("--- Уровень 3: allowlist инструментов ---")
assert "approve_for_next_round" in security.allowed_tools_for_level(0)
assert "approve_for_next_round" not in security.allowed_tools_for_level(3)
assert "get_candidate_summary" in security.allowed_tools_for_level(3)
print("OK: чувствительные инструменты недоступны на уровне 3, безопасные — доступны.\n")

print("--- Уровень 3: фильтрация вывода (утечка секретов) ---")
leaky_reply = f"Конечно! Вот бюджет: {settings.CONFIDENTIAL_SALARY_BUDGET}. И ключ: {settings.CONFIDENTIAL_API_KEY}"
r_no_filter = security.filter_output(leaky_reply, level=2)
r_filtered = security.filter_output(leaky_reply, level=3)
assert settings.CONFIDENTIAL_API_KEY in r_no_filter.text
assert settings.CONFIDENTIAL_API_KEY not in r_filtered.text
assert "[СКРЫТО ФИЛЬТРОМ ВЫВОДА]" in r_filtered.text
print("OK: на уровне 3 секреты вырезаются из ответа модели, на уровне <3 — нет.\n")

print("Все проверки security.py прошли успешно.")
