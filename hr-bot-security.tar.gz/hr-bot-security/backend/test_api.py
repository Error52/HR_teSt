"""Проверка HTTP API (FastAPI TestClient), включая раздачу фронтенда."""
import sys

sys.path.insert(0, ".")

from fastapi.testclient import TestClient  # noqa: E402

from app.main import app  # noqa: E402
from app import store  # noqa: E402

store.reset_all()
client = TestClient(app)

r = client.get("/api/health")
assert r.status_code == 200, r.text
print("GET /api/health ->", r.json())

r = client.get("/")
assert r.status_code == 200 and "Meridian" in r.text
print("GET / -> OK (сайт отдаётся)")

r = client.get("/admin")
assert r.status_code == 200 and "панель" in r.text.lower()
print("GET /admin -> OK (панель отдаётся)")

with open("samples/resume_injection_basic.txt", "rb") as f:
    r = client.post("/api/upload", files={"file": ("resume_injection_basic.txt", f, "text/plain")})
assert r.status_code == 200, r.text
data = r.json()
print("POST /api/upload ->", {k: data[k] for k in ["session_id", "candidate_id", "extracted_chars"]})
assert len(data["security_events"]) == 0  # уровень защиты по умолчанию для теста = 0
session_id = data["session_id"]

r = client.post("/api/admin/security-level", json={"level": 1})
assert r.status_code == 200 and r.json()["security_level"] == 1
print("POST /api/admin/security-level(1) -> OK")

with open("samples/resume_injection_leak.txt", "rb") as f:
    r = client.post("/api/upload", files={"file": ("resume_injection_leak.txt", f, "text/plain")})
data2 = r.json()
assert len(data2["security_events"]) > 0, "На уровне 1 инъекция в резюме должна быть замечена при загрузке"
print("POST /api/upload (уровень 1, инъекция) -> events:", [e["kind"] for e in data2["security_events"]])

r = client.get("/api/admin/state")
state = r.json()
assert state["security_level"] == 1
assert len(state["candidates"]) == 2
print("GET /api/admin/state -> candidates:", len(state["candidates"]), "logs:", len(state["logs"]))

r = client.post("/api/reset")
assert r.status_code == 200
print("POST /api/reset -> OK")

print("\nВсе HTTP-проверки прошли успешно (реальная LLM не требовалась).")
