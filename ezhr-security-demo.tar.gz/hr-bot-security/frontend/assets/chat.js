const backdrop = document.getElementById("modalBackdrop");
const openBtns = [document.getElementById("openScreenerBtn"), document.getElementById("openScreenerBtn2")];
const closeBtn = document.getElementById("closeModal");
const fileInput = document.getElementById("fileInput");
const dropZone = document.getElementById("dropZone");
const uploadStep = document.getElementById("uploadStep");
const chatLog = document.getElementById("chatLog");
const chatFoot = document.getElementById("chatFoot");
const chatInput = document.getElementById("chatInput");
const sendBtn = document.getElementById("sendBtn");
const levelBadge = document.getElementById("levelBadge");

let sessionId = null;

openBtns.forEach((b) => b && b.addEventListener("click", () => backdrop.classList.add("open")));
closeBtn.addEventListener("click", () => backdrop.classList.remove("open"));
backdrop.addEventListener("click", (e) => { if (e.target === backdrop) backdrop.classList.remove("open"); });

async function refreshLevel() {
  try {
    const r = await fetch("/api/health");
    const d = await r.json();
    levelBadge.textContent = `уровень защиты: ${d.security_level}`;
  } catch (e) {
    levelBadge.textContent = "уровень защиты: н/д";
  }
}
refreshLevel();
setInterval(refreshLevel, 4000);

fileInput.addEventListener("change", async () => {
  const file = fileInput.files[0];
  if (!file) return;
  const fd = new FormData();
  fd.append("file", file);

  dropZone.innerHTML = "<div>Загрузка и анализ файла…</div>";

  try {
    const resp = await fetch("/api/upload", { method: "POST", body: fd });
    if (!resp.ok) {
      const err = await resp.json().catch(() => ({ detail: "Ошибка загрузки" }));
      dropZone.innerHTML = `<div>Ошибка: ${err.detail}</div>`;
      return;
    }
    const data = await resp.json();
    sessionId = data.session_id;

    uploadStep.style.display = "none";
    chatLog.style.display = "flex";
    chatFoot.style.display = "flex";

    addMsg("sys", `Файл «${data.filename}» загружен и обработан (${data.extracted_chars} символов).`);
    if (data.security_events && data.security_events.length) {
      data.security_events.forEach((e) => addMsg("sys", `⚠ ${e.detail}`));
    }
    addMsg("bot", "Здравствуйте! Я Ева, AI-ассистент ezHR. Я ознакомилась с вашим резюме — спрашивайте, что вас интересует по вакансии.");
  } catch (e) {
    dropZone.innerHTML = "<div>Не удалось связаться с сервером.</div>";
  }
});

function addMsg(role, text) {
  const div = document.createElement("div");
  div.className = `msg ${role}`;
  div.textContent = text;
  chatLog.appendChild(div);
  chatLog.scrollTop = chatLog.scrollHeight;
}

async function send() {
  const text = chatInput.value.trim();
  if (!text || !sessionId) return;
  addMsg("user", text);
  chatInput.value = "";
  sendBtn.disabled = true;

  try {
    const resp = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ session_id: sessionId, message: text }),
    });
    const data = await resp.json();

    if (data.security_events && data.security_events.length) {
      data.security_events.forEach((e) => addMsg("sys", `⚠ ${e.detail}`));
    }
    if (data.tool_events && data.tool_events.length) {
      data.tool_events.forEach((t) => {
        const tag = t.blocked ? "заблокирован" : t.pending ? "требует подтверждения" : "выполнен";
        addMsg("sys", `🔧 Инструмент ${t.name} (${tag}): ${t.result}`);
      });
    }
    addMsg("bot", data.reply || "(нет ответа)");
    refreshLevel();
  } catch (e) {
    addMsg("sys", "Ошибка соединения с сервером.");
  } finally {
    sendBtn.disabled = false;
  }
}

sendBtn.addEventListener("click", send);
chatInput.addEventListener("keydown", (e) => { if (e.key === "Enter") send(); });
