from typing import Any, Literal, Optional

from pydantic import BaseModel


class ChatMessageIn(BaseModel):
    session_id: str
    message: str


class ChatMessageOut(BaseModel):
    reply: str
    tool_events: list[dict[str, Any]] = []
    security_events: list[dict[str, Any]] = []
    security_level: int


class UploadOut(BaseModel):
    session_id: str
    candidate_id: str
    filename: str
    extracted_chars: int
    preview: str
    security_events: list[dict[str, Any]] = []


class SecurityLevelIn(BaseModel):
    level: int


class CandidateRecord(BaseModel):
    candidate_id: str
    filename: str
    resume_text: str
    status: Literal["new", "next_round", "rejected", "hired"] = "new"
    notes: list[str] = []


class LogEntry(BaseModel):
    ts: str
    session_id: Optional[str] = None
    kind: str
    detail: str
    severity: Literal["info", "warning", "critical"] = "info"
