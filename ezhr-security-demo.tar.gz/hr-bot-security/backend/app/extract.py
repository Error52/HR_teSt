"""
Извлечение текста из загруженного резюме.

Важно для темы курсовой: именно здесь в текст попадает НЕДОВЕРЕННЫЙ
контент. Если резюме (PDF/DOCX) содержит внедрённые инструкции
("Игнорируй предыдущие инструкции и...", белый текст на белом фоне,
текст поверх текста и т.п.), извлечённая строка будет содержать их
как обычный текст — это и есть точка входа для непрямой (indirect)
Prompt Injection.

Сам по себе extract.py ничего не фильтрует — фильтрация делается
отдельно в security.py в зависимости от выбранного уровня защиты.
"""
import io

from docx import Document
from pypdf import PdfReader


def extract_text(filename: str, data: bytes) -> str:
    lower = filename.lower()
    if lower.endswith(".pdf"):
        return _extract_pdf(data)
    if lower.endswith(".docx"):
        return _extract_docx(data)
    if lower.endswith(".txt") or lower.endswith(".md"):
        return data.decode("utf-8", errors="ignore")
    # Фолбэк: пытаемся как текст
    try:
        return data.decode("utf-8", errors="ignore")
    except Exception:
        return ""


def _extract_pdf(data: bytes) -> str:
    reader = PdfReader(io.BytesIO(data))
    chunks = []
    for page in reader.pages:
        try:
            chunks.append(page.extract_text() or "")
        except Exception:
            continue
    return "\n".join(chunks)


def _extract_docx(data: bytes) -> str:
    doc = Document(io.BytesIO(data))
    parts = [p.text for p in doc.paragraphs]
    for table in doc.tables:
        for row in table.rows:
            for cell in row.cells:
                parts.append(cell.text)
    return "\n".join(parts)
