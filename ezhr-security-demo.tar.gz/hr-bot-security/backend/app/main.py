import os

from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from . import store
from .config import settings
from .extract import extract_text
from .llm import run_agent
from .models import ChatMessageIn, SecurityLevelIn, UploadOut
from .security import filter_user_input

app = FastAPI(title=settings.APP_TITLE)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/api/health")
async def health():
    return {"status": "ok", "security_level": store.get_security_level(), "model": settings.OLLAMA_MODEL}


@app.post("/api/upload", response_model=UploadOut)
async def upload_resume(file: UploadFile = File(...)):
    data = await file.read()
    if len(data) > settings.MAX_UPLOAD_MB * 1024 * 1024:
        raise HTTPException(413, f"Файл больше {settings.MAX_UPLOAD_MB} МБ")

    text = extract_text(file.filename or "resume.txt", data)
    if not text.strip():
        raise HTTPException(400, "Не удалось извлечь текст из файла. Поддерживаются PDF, DOCX, TXT.")

    level = store.get_security_level()

    # Резюме — это тоже пользовательский ввод (просто он приходит файлом,
    # а не текстовым полем), поэтому к нему применяется тот же входной
    # фильтр уровня 1, что и к сообщениям чата.
    filt = filter_user_input(text, level)
    security_events = [{"kind": e.kind, "detail": e.detail, "severity": e.severity} for e in filt.events]
    for e in filt.events:
        store.log_event(e.kind, f"[upload:{file.filename}] {e.detail}", severity=e.severity)

    candidate_id = store.new_id("cand")
    store.save_candidate(candidate_id, file.filename or "resume", filt.text)

    session = store.create_session(candidate_id)
    store.log_event("upload", f"Загружено резюме '{file.filename}', {len(text)} символов", severity="info", session_id=session["session_id"])

    return UploadOut(
        session_id=session["session_id"],
        candidate_id=candidate_id,
        filename=file.filename or "resume",
        extracted_chars=len(text),
        preview=filt.text[:500],
        security_events=security_events,
    )


@app.post("/api/chat")
async def chat(payload: ChatMessageIn):
    if not store.get_session(payload.session_id):
        raise HTTPException(404, "Сессия не найдена, загрузите резюме заново")
    result = await run_agent(payload.session_id, payload.message)
    return result


@app.post("/api/reset")
async def reset():
    store.reset_all()
    return {"status": "ok"}


# ---------------------------------------------------------------------
# Панель администратора / рекрутера — для наблюдения за атаками и
# переключения уровней защиты вживую во время демонстрации.
# ---------------------------------------------------------------------
@app.get("/api/admin/state")
async def admin_state():
    return {
        "security_level": store.get_security_level(),
        "candidates": [c.model_dump() for c in store.candidates.values()],
        "logs": [l.model_dump() for l in store.logs[-200:]],
        "outbox": store.outbox,
        "model": settings.OLLAMA_MODEL,
    }


@app.post("/api/admin/security-level")
async def set_level(payload: SecurityLevelIn):
    store.set_security_level(payload.level)
    return {"security_level": store.get_security_level()}


# ---------------------------------------------------------------------
# Статика фронтенда (сайт HR-агентства + панель администратора).
#
# По умолчанию ищем frontend/ на два уровня выше этого файла — это верно
# и для локального запуска (backend/app/main.py -> ../../frontend), и
# внутри Docker-образа (/app/app/main.py -> /app/frontend), т.к.
# Dockerfile копирует backend и frontend с сохранением этой структуры.
# Можно переопределить через переменную окружения FRONTEND_DIR.
# ---------------------------------------------------------------------
FRONTEND_DIR = os.getenv(
    "FRONTEND_DIR",
    os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "frontend")),
)

app.mount("/assets", StaticFiles(directory=os.path.join(FRONTEND_DIR, "assets")), name="assets")


@app.get("/")
async def index():
    return FileResponse(os.path.join(FRONTEND_DIR, "index.html"))


@app.get("/admin")
async def admin_page():
    return FileResponse(os.path.join(FRONTEND_DIR, "admin.html"))
