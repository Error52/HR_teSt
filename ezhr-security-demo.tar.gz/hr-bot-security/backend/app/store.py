"""
Простое in-memory хранилище состояния приложения (демо-стенд, не для продакшена).

Хранит:
- сессии чата (история сообщений, привязанный кандидат)
- "базу" кандидатов и их статусы (используется, чтобы показать реальный
  ущерб от атаки: ИИ-агент может сам перевести кандидата на следующий
  этап / нанять, если у него есть неограниченные полномочия)
- журнал событий безопасности (для вкладки "Атаки" в панели администратора)
"""
import itertools
import threading
from datetime import datetime, timezone
from typing import Any, Optional

from .config import settings
from .models import CandidateRecord, LogEntry

_lock = threading.Lock()

_id_counter = itertools.count(1)

sessions: dict[str, dict[str, Any]] = {}
candidates: dict[str, CandidateRecord] = {}
logs: list[LogEntry] = []
security_state: dict[str, int] = {"level": settings.DEFAULT_SECURITY_LEVEL}
outbox: list[dict[str, str]] = []  # для демонстрации эксфильтрации через send_email


def new_id(prefix: str) -> str:
    return f"{prefix}-{next(_id_counter):05d}"


def log_event(kind: str, detail: str, severity: str = "info", session_id: Optional[str] = None) -> LogEntry:
    entry = LogEntry(
        ts=datetime.now(timezone.utc).isoformat(timespec="seconds"),
        session_id=session_id,
        kind=kind,
        detail=detail,
        severity=severity,
    )
    with _lock:
        logs.append(entry)
        if len(logs) > 500:
            del logs[: len(logs) - 500]
    return entry


def get_security_level() -> int:
    return security_state["level"]


def set_security_level(level: int) -> None:
    level = max(0, min(3, level))
    security_state["level"] = level
    log_event("config", f"Уровень защиты изменён на {level}", severity="info")


def create_session(candidate_id: str) -> dict[str, Any]:
    session_id = new_id("sess")
    sessions[session_id] = {
        "candidate_id": candidate_id,
        "history": [],
    }
    return {"session_id": session_id, **sessions[session_id]}


def get_session(session_id: str) -> Optional[dict[str, Any]]:
    return sessions.get(session_id)


def save_candidate(candidate_id: str, filename: str, resume_text: str) -> CandidateRecord:
    rec = CandidateRecord(candidate_id=candidate_id, filename=filename, resume_text=resume_text)
    candidates[candidate_id] = rec
    return rec


def get_candidate(candidate_id: str) -> Optional[CandidateRecord]:
    return candidates.get(candidate_id)


def reset_all() -> None:
    sessions.clear()
    candidates.clear()
    logs.clear()
    outbox.clear()
