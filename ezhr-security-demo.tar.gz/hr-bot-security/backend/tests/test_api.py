"""HTTP-уровень (FastAPI TestClient): раздача фронтенда, загрузка резюме,
переключение уровня защиты. Реальная LLM не требуется — маршруты,
затрагивающие /api/chat, покрыты отдельно в test_prompt_injection_flow.py."""
import os

from fastapi.testclient import TestClient

from app.main import app


client = TestClient(app)


def test_health():
    r = client.get("/api/health")
    assert r.status_code == 200
    body = r.json()
    assert "security_level" in body
    assert "model" in body


def test_site_is_served():
    r = client.get("/")
    assert r.status_code == 200
    assert "ezHR" in r.text


def test_admin_panel_is_served():
    r = client.get("/admin")
    assert r.status_code == 200
    assert "панель" in r.text.lower()


def test_upload_and_injection_detection(samples_dir):
    # Уровень 0: инъекция в резюме не фильтруется при загрузке.
    with open(os.path.join(samples_dir, "resume_injection_basic.txt"), "rb") as f:
        r = client.post("/api/upload", files={"file": ("resume_injection_basic.txt", f, "text/plain")})
    assert r.status_code == 200
    data = r.json()
    assert data["security_events"] == []
    assert data["session_id"]

    # Поднимаем уровень защиты и повторяем — теперь фильтр должен сработать.
    r = client.post("/api/admin/security-level", json={"level": 1})
    assert r.status_code == 200 and r.json()["security_level"] == 1

    with open(os.path.join(samples_dir, "resume_injection_leak.txt"), "rb") as f:
        r = client.post("/api/upload", files={"file": ("resume_injection_leak.txt", f, "text/plain")})
    data2 = r.json()
    assert len(data2["security_events"]) > 0


def test_admin_state_reflects_uploads(samples_dir):
    with open(os.path.join(samples_dir, "resume_clean.txt"), "rb") as f:
        client.post("/api/upload", files={"file": ("resume_clean.txt", f, "text/plain")})

    r = client.get("/api/admin/state")
    state = r.json()
    assert len(state["candidates"]) >= 1
    assert isinstance(state["logs"], list)


def test_upload_rejects_empty_text_file():
    r = client.post("/api/upload", files={"file": ("empty.txt", b"   ", "text/plain")})
    assert r.status_code == 400
