"""Модульные тесты app.security на текстах реальных примеров атак
из backend/samples/."""
import os

import pytest

from app import security
from app.config import settings


def _read_sample(samples_dir: str, name: str) -> str:
    with open(os.path.join(samples_dir, name), encoding="utf-8") as f:
        return f.read()


@pytest.fixture
def clean_resume(samples_dir) -> str:
    return _read_sample(samples_dir, "resume_clean.txt")


@pytest.fixture
def basic_injection(samples_dir) -> str:
    return _read_sample(samples_dir, "resume_injection_basic.txt")


@pytest.fixture
def leak_injection(samples_dir) -> str:
    return _read_sample(samples_dir, "resume_injection_leak.txt")


class TestInputFiltering:
    """Уровень 1: многоуровневая фильтрация пользовательского ввода."""

    def test_clean_resume_has_no_findings(self, clean_resume):
        result = security.filter_user_input(clean_resume, level=1)
        assert result.events == []

    def test_basic_injection_is_detected(self, basic_injection):
        result = security.filter_user_input(basic_injection, level=1)
        kinds = {e.kind for e in result.events}
        assert "injection_detected" in kinds

    def test_leak_attempt_is_detected(self, leak_injection):
        result = security.filter_user_input(leak_injection, level=1)
        kinds = {e.kind for e in result.events}
        assert "injection_detected" in kinds

    def test_filtering_disabled_at_level_zero(self, basic_injection):
        result = security.filter_user_input(basic_injection, level=0)
        assert result.events == []
        assert result.text == basic_injection


class TestInstructionIsolation:
    """Уровень 2: изоляция системных инструкций (spotlighting)."""

    def test_untrusted_wrapper_applied_from_level_2(self, basic_injection):
        wrapped = security.wrap_untrusted("resume_file", basic_injection, level=2)
        assert "<untrusted_data" in wrapped
        assert "ДАННЫЕ" in wrapped

    def test_untrusted_wrapper_absent_below_level_2(self, basic_injection):
        not_wrapped = security.wrap_untrusted("resume_file", basic_injection, level=1)
        assert not_wrapped == basic_injection

    def test_sandwich_reminder_only_from_level_2(self):
        assert security.sandwich_reminder(1) == ""
        assert security.sandwich_reminder(2) != ""


class TestPrivilegeLimitation:
    """Уровень 3: ограничение полномочий ИИ-агента."""

    def test_sensitive_tools_allowed_below_level_3(self):
        allowed = security.allowed_tools_for_level(0)
        assert "approve_for_next_round" in allowed
        assert "send_email" in allowed

    def test_sensitive_tools_blocked_at_level_3(self):
        allowed = security.allowed_tools_for_level(3)
        assert "approve_for_next_round" not in allowed
        assert "send_email" not in allowed
        assert "get_candidate_summary" in allowed  # безопасный инструмент остаётся

    def test_output_filter_redacts_secrets_at_level_3(self):
        leaky_reply = (
            f"Конечно! Вот бюджет: {settings.CONFIDENTIAL_SALARY_BUDGET}. "
            f"И ключ: {settings.CONFIDENTIAL_API_KEY}"
        )
        unfiltered = security.filter_output(leaky_reply, level=2)
        filtered = security.filter_output(leaky_reply, level=3)

        assert settings.CONFIDENTIAL_API_KEY in unfiltered.text
        assert settings.CONFIDENTIAL_API_KEY not in filtered.text
        assert "[СКРЫТО ФИЛЬТРОМ ВЫВОДА]" in filtered.text
