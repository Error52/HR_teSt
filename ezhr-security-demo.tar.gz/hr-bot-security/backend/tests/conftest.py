import os
import sys

import pytest

BACKEND_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SAMPLES_DIR = os.path.join(BACKEND_ROOT, "samples")

if BACKEND_ROOT not in sys.path:
    sys.path.insert(0, BACKEND_ROOT)


@pytest.fixture(scope="session")
def samples_dir() -> str:
    return SAMPLES_DIR


@pytest.fixture(autouse=True)
def _reset_store():
    """Каждый тест начинает с чистого состояния in-memory хранилища,
    чтобы тесты не влияли друг на друга (кандидаты, сессии, журнал)."""
    from app import store

    store.reset_all()
    store.set_security_level(0)
    yield
    store.reset_all()
